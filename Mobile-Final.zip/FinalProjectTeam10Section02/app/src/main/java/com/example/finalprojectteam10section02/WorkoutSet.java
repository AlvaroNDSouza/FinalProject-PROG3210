package com.example.finalprojectteam10section02;

public class WorkoutSet {
    private long id;  // Use 'long' for ID to ensure compatibility with SQLite's row ID
    private int sets;
    private int reps;

    // Constructor (optional, can help to create a new object more easily)
    public WorkoutSet(long id, int sets, int reps) {
        this.id = id;
        this.sets = sets;
        this.reps = reps;
    }

    // Default constructor
    public WorkoutSet() {
    }

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getSets() {
        return sets;
    }

    public void setSets(int sets) {
        this.sets = sets;
    }

    public int getReps() {
        return reps;
    }

    public void setReps(int reps) {
        this.reps = reps;
    }

    // Additional methods (if needed), such as toString, equals, or hashCode
}
