package com.example.finalprojectteam10section02;

public class Workout {
    private long id;
    private String name;
    private String date;

    // Constructor, getters, and setters

    public Workout() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
