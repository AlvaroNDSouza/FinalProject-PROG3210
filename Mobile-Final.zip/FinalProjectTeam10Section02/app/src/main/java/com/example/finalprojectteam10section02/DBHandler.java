package com.example.finalprojectteam10section02;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.Console;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class DBHandler extends SQLiteOpenHelper {

    // Database name
    private static final String DB_NAME = "fitplusdb";

    // Database version
    private static final int DB_VERSION = 2;

    // USER TABLE
    // Table names
    private static final String TABLE_USER = "user";

    // Variables for user's table column
    private static final String USERID_COL = "userId";
    private static final String NAME_COL = "name";
    private static final String DOB_COL = "dob";
    private static final String EMAIL_COL = "email";
    private static final String GENDER_COL = "gender";
    private static final String PASSWORD_COL = "password";

    // OTHER TABLES
    // Table Names
    private static final String TABLE_WORKOUT = "Workout";
    private static final String TABLE_EXERCISE = "Exercise";
    private static final String TABLE_WORKOUT_SET = "WorkoutSet"; // Renamed to avoid reserved keyword conflict

    // Common column names
    private static final String COLUMN_ID = "_id";

    // WORKOUT Table - column names
    private static final String COLUMN_WORKOUT_ID = "workout_id";
    private static final String COLUMN_WORKOUT_DATE = "workout_date";
    private static final String COLUMN_WORKOUT_NAME = "workout_name";

    // EXERCISE Table - column names
    private static final String COLUMN_EXERCISE_ID = "exercise_id";
    private static final String COLUMN_EXERCISE_NAME = "exercise_name";

    // WORKOUT_SET Table - column names
    private static final String COLUMN_SET_ID = "set_id";
    private static final String COLUMN_SET_EXERCISE_ID = "exercise_id";
    private static final String COLUMN_SETS = "sets";
    private static final String COLUMN_REPS = "reps";

    // Constructor
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Creating a database by running the SQLite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // User table creation
        String createUserTable = "CREATE TABLE " + TABLE_USER + " ("
                + USERID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + DOB_COL + " TEXT,"
                + EMAIL_COL + " TEXT,"
                + GENDER_COL + " TEXT,"
                + PASSWORD_COL + " TEXT)";
        db.execSQL(createUserTable);

        // Workout table creation
        String createWorkoutTable = "CREATE TABLE " + TABLE_WORKOUT + " ("
                + COLUMN_WORKOUT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_WORKOUT_DATE + " TEXT, "
                + COLUMN_WORKOUT_NAME + " TEXT)";
        db.execSQL(createWorkoutTable);

        // Exercise table creation code
        String createExerciseTable = "CREATE TABLE " + TABLE_EXERCISE + " ("
                + COLUMN_EXERCISE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_WORKOUT_ID + " INTEGER, "
                + COLUMN_EXERCISE_NAME + " TEXT, "
                + "FOREIGN KEY(" + COLUMN_WORKOUT_ID + ") REFERENCES "
                + TABLE_WORKOUT + "(" + COLUMN_WORKOUT_ID + "))";
        db.execSQL(createExerciseTable);

        // WorkoutSet table creation
        String createWorkoutSetTable = "CREATE TABLE " + TABLE_WORKOUT_SET + " ("
                + COLUMN_SET_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_SET_EXERCISE_ID + " INTEGER, "
                + COLUMN_SETS + " INTEGER, "
                + COLUMN_REPS + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_SET_EXERCISE_ID + ") REFERENCES "
                + TABLE_EXERCISE + "(" + COLUMN_EXERCISE_ID + "))";
        db.execSQL(createWorkoutSetTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORKOUT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXERCISE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORKOUT_SET);
        // Create tables again
        onCreate(db);
    }

    // Method to add a new user in the database
    public void addNewUser(String name, String dob, String email, String gender, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME_COL, name);
        values.put(DOB_COL, dob);
        values.put(EMAIL_COL, email);
        values.put(GENDER_COL, gender);
        values.put(PASSWORD_COL, password);
        db.insert(TABLE_USER, null, values);
        db.close();
    }

    // Method to find a password by email
    public String findPasswordByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String password = "-1";
        Cursor cursor = db.query(TABLE_USER, new String[]{PASSWORD_COL}, EMAIL_COL + "=?", new String[]{email}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            password = cursor.getString(0);
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return password;
    }
    public long addWorkout(String workoutName, String workoutDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WORKOUT_DATE, workoutDate);
        values.put(COLUMN_WORKOUT_NAME, workoutName);
        long workoutId = db.insert(TABLE_WORKOUT, null, values);
        db.close();
        return workoutId;
    }
    public Workout getWorkoutById(long workoutId) {
        Workout workout = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WORKOUT, new String[]{COLUMN_WORKOUT_ID, COLUMN_WORKOUT_NAME, COLUMN_WORKOUT_DATE}, COLUMN_WORKOUT_ID + " = ?", new String[]{String.valueOf(workoutId)}, null, null, null);

        int idIndex = cursor.getColumnIndex(COLUMN_WORKOUT_ID);
        int nameIndex = cursor.getColumnIndex(COLUMN_WORKOUT_NAME);
        int dateIndex = cursor.getColumnIndex(COLUMN_WORKOUT_DATE);

        if (idIndex != -1 && nameIndex != -1 && dateIndex != -1) {
            if (cursor.moveToFirst()) {
                workout = new Workout();
                workout.setId(cursor.getLong(idIndex));
                workout.setName(cursor.getString(nameIndex));
                workout.setDate(cursor.getString(dateIndex));
            }
        }
        cursor.close();
        db.close();
        return workout;
    }

    public long addExercise(long workoutId, String exerciseName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WORKOUT_ID, workoutId);
        values.put(COLUMN_EXERCISE_NAME, exerciseName);
        long exerciseId = db.insert(TABLE_EXERCISE, null, values);
        db.close();
        return exerciseId;
    }
    public void addSetToExercise(long exerciseId, int sets, int reps) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SET_EXERCISE_ID, exerciseId);
        values.put(COLUMN_SETS, sets);
        values.put(COLUMN_REPS, reps);
        db.insert(TABLE_WORKOUT_SET, null, values);
        db.close();
    }
    public int editExercise(long exerciseId, String newExerciseName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EXERCISE_NAME, newExerciseName);
        int rowsAffected = db.update(TABLE_EXERCISE, values, COLUMN_EXERCISE_ID + " = ?", new String[]{String.valueOf(exerciseId)});
        db.close();
        return rowsAffected;
    }
    public void deleteExercise(long exerciseId) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete all sets related to the exercise
        db.delete(TABLE_WORKOUT_SET, COLUMN_SET_EXERCISE_ID + " = ?", new String[]{String.valueOf(exerciseId)});
        // Now delete the exercise
        db.delete(TABLE_EXERCISE, COLUMN_EXERCISE_ID + " = ?", new String[]{String.valueOf(exerciseId)});
        db.close();
    }
    public void deleteWorkout(long workoutId) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Get all exercises related to the workout
        List<Long> exerciseIds = getExerciseIdsByWorkout(workoutId);
        // Delete all sets for each exercise
        for (long exerciseId : exerciseIds) {
            db.delete(TABLE_WORKOUT_SET, COLUMN_SET_EXERCISE_ID + " = ?", new String[]{String.valueOf(exerciseId)});
        }
        // Delete all exercises related to the workout
        db.delete(TABLE_EXERCISE, COLUMN_WORKOUT_ID + " = ?", new String[]{String.valueOf(workoutId)});
        db.delete(TABLE_WORKOUT, COLUMN_WORKOUT_ID + " = ?", new String[]{String.valueOf(workoutId)});
        db.close();
    }

    private List<Long> getExerciseIdsByWorkout(long workoutId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Long> exerciseIds = new ArrayList<>();
        Cursor cursor = db.query(TABLE_EXERCISE, new String[]{COLUMN_EXERCISE_ID}, COLUMN_WORKOUT_ID + " = ?", new String[]{String.valueOf(workoutId)}, null, null, null);
        int columnIndex = cursor.getColumnIndex(COLUMN_EXERCISE_ID);

        if (columnIndex != -1) {
            while (cursor.moveToNext()) {
                exerciseIds.add(cursor.getLong(columnIndex));
            }
        } else {
            System.out.print("There has been an error");
        }
        cursor.close();
        db.close();
        return exerciseIds;
    }
    public List<Exercise> getExercisesForWorkout(long workoutId) {
        List<Exercise> exerciseList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EXERCISE, new String[]{COLUMN_EXERCISE_ID, COLUMN_EXERCISE_NAME}, COLUMN_WORKOUT_ID + " = ?", new String[]{String.valueOf(workoutId)}, null, null, null);

        int idIndex = cursor.getColumnIndex(COLUMN_EXERCISE_ID);
        int nameIndex = cursor.getColumnIndex(COLUMN_EXERCISE_NAME);

        if (idIndex != -1 && nameIndex != -1) {
            if (cursor.moveToFirst()) {
                do {
                    Exercise exercise = new Exercise();
                    exercise.setId(cursor.getLong(idIndex));
                    exercise.setWorkoutId(workoutId);
                    exercise.setName(cursor.getString(nameIndex));
                    exerciseList.add(exercise);
                } while (cursor.moveToNext());
            }
        }
        cursor.close();
        db.close();
        return exerciseList;
    }
    public List<Workout> getAllWorkouts() {
        List<Workout> workoutList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WORKOUT, new String[]{
                COLUMN_WORKOUT_ID, COLUMN_WORKOUT_NAME, COLUMN_WORKOUT_DATE
        }, null, null, null, null, null);

        int idIndex = cursor.getColumnIndex(COLUMN_WORKOUT_ID);
        int nameIndex = cursor.getColumnIndex(COLUMN_WORKOUT_NAME);
        int dateIndex = cursor.getColumnIndex(COLUMN_WORKOUT_DATE);

        if (idIndex != -1 && nameIndex != -1 && dateIndex != -1) {
            if (cursor.moveToFirst()) {
                do {
                    Workout workout = new Workout();
                    workout.setId(cursor.getLong(idIndex));
                    workout.setName(cursor.getString(nameIndex));
                    workout.setDate(cursor.getString(dateIndex));
                    workoutList.add(workout);
                } while (cursor.moveToNext());
            }
        }
        cursor.close();
        db.close();
        return workoutList;
    }
    // Method inside DBHandler to fetch all sets and reps for a specific exercise
    public List<WorkoutSet> getSetsForExercise(long exerciseId) {
        List<WorkoutSet> setsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Assuming COLUMN_SETS and COLUMN_REPS are correctly defined as "sets" and "reps"
        // at the top of your DBHandler class as constants, mirroring exactly the database column names
        String[] columns = {COLUMN_SET_ID, COLUMN_SETS, COLUMN_REPS};
        String selection = COLUMN_SET_EXERCISE_ID + " = ?";
        String[] selectionArgs = {String.valueOf(exerciseId)};

        Cursor cursor = db.query(TABLE_WORKOUT_SET, columns, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                WorkoutSet set = new WorkoutSet();
                set.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_SET_ID)));
                set.setSets(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_SETS)));
                set.setReps(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_REPS)));
                setsList.add(set);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return setsList;
    }


}
