// Camila Terra Ramalho

package com.example.finalprojectteam10section02;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //creating variables for edittext
    private EditText editTextTextEmailAddress, editTextTextPassword;

    //creating variables for buttons
    private Button buttonSignin, buttonCreateAccount;

    //creating variables for dbhandler
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializing all variables
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        editTextTextPassword = findViewById(R.id.editTextTextPassword);
        buttonSignin = findViewById(R.id.buttonSignin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);


        dbHandler = new DBHandler( MainActivity.this);

        buttonSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextTextEmailAddress.getText().toString();
                String password = editTextTextPassword.getText().toString();
                String pass;

                pass = dbHandler.findPasswordByEmail(email);
                if(pass.equals(password)){
                    Intent intentHomePage = new Intent(getApplicationContext(), Home.class);
                    startActivity(intentHomePage);
                    Toast.makeText(getApplicationContext(), "Data correct", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (pass.equals("-1")){
                        Toast.makeText(getApplicationContext(), "Email not found, make a registration", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Password does not match", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCreateAccount = new Intent(getApplicationContext(), CreateAccount.class);
                startActivity(intentCreateAccount);

            }
        });



        //
    }
}