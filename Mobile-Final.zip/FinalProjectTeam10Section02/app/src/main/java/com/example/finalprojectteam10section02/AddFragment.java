package com.example.finalprojectteam10section02;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.Fragment;
import com.example.finalprojectteam10section02.databinding.ActivityHomeBinding;
public class AddFragment extends Fragment {

    private EditText editTextWorkoutName;
    private EditText editTextWorkoutDate;
    private Button buttonCreateWorkout;
    private DBHandler dbHandler;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add, container, false);

        editTextWorkoutName = view.findViewById(R.id.editTextWorkoutName);
        editTextWorkoutDate = view.findViewById(R.id.editTextWorkoutDate);
        buttonCreateWorkout = view.findViewById(R.id.buttonCreateWorkout);

        dbHandler = new DBHandler(getActivity());

        buttonCreateWorkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String workoutName = editTextWorkoutName.getText().toString().trim();
                String workoutDate = editTextWorkoutDate.getText().toString().trim();

                // Validate inputs
                if (!workoutName.isEmpty() && !workoutDate.isEmpty()) {
                    long workoutId = dbHandler.addWorkout(workoutName, workoutDate);
                    Log.d("AddFragment", "Workout ID: " + workoutId);
                    if (workoutId != -1) {
                        AddExercise addExerciseFragment = new AddExercise();
                        Bundle bundle = new Bundle();
                        bundle.putLong("workout_id", workoutId);
                        addExerciseFragment.setArguments(bundle);
                        replaceFragment(addExerciseFragment);
                    } else {
                        // Handle the error case here
                    }
                } else {
                    // Prompt the user that the fields cannot be empty
                }
            }
        });

        return view;
    }
    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commitAllowingStateLoss();
    }
}