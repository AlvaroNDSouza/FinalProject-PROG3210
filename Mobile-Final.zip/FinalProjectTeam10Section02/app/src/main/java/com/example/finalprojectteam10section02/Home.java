package com.example.finalprojectteam10section02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.finalprojectteam10section02.databinding.ActivityHomeBinding;



public class Home extends AppCompatActivity {
 ActivityHomeBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.homeIcon) {
                replaceFragment(new HomeFragment());
            }
            else if (item.getItemId() == R.id.addIcon) {
                replaceFragment(new AddFragment());
            }
            else if (item.getItemId() == R.id.profileIcon) {
                replaceFragment(new ProfileFragment());
            }
            return true;
        });
}
private void replaceFragment(Fragment fragment){
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    fragmentTransaction.replace(R.id.frame_layout,fragment);
    fragmentTransaction.commit();
}
}