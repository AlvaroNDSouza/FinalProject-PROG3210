package com.example.finalprojectteam10section02;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Button;
import androidx.fragment.app.Fragment;

public class AddExercise extends Fragment {

    private AutoCompleteTextView autoCompleteExerciseName;
    private EditText editTextNumberOfSets;
    private EditText editTextNumberOfReps;
    private Button buttonAddExercise;
    private DBHandler dbHandler;
    private long workoutId;

    public static AddExercise newInstance(long workoutId) {
        AddExercise fragment = new AddExercise();
        Bundle args = new Bundle();
        args.putLong("workout_id", workoutId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_exercise, container, false);

        autoCompleteExerciseName = view.findViewById(R.id.autoCompleteExerciseName);
        editTextNumberOfSets = view.findViewById(R.id.editTextNumberOfSets);
        editTextNumberOfReps = view.findViewById(R.id.editTextNumberOfReps);
        buttonAddExercise = view.findViewById(R.id.buttonAddExercise);

        dbHandler = new DBHandler(getActivity());
        if (getArguments() != null) {
            workoutId = getArguments().getLong("workout_id", -1);
        }

        buttonAddExercise.setOnClickListener(v -> {
            String exerciseName = autoCompleteExerciseName.getText().toString().trim();
            String sets = editTextNumberOfSets.getText().toString().trim();
            String reps = editTextNumberOfReps.getText().toString().trim();

            // Validate inputs
            if (!exerciseName.isEmpty() && !sets.isEmpty() && !reps.isEmpty()) {
                try {
                    int numberOfSets = Integer.parseInt(sets);
                    int numberOfReps = Integer.parseInt(reps);

                    // Add exercise to the workout
                    long exerciseId = dbHandler.addExercise(workoutId, exerciseName);
                    if (exerciseId != -1) {
                        // Add sets and reps to the exercise
                        dbHandler.addSetToExercise(exerciseId, numberOfSets, numberOfReps);
                        Log.d("AddExercise", "Success: " + workoutId);
                    } else {
                        // Handle the error case here
                    }
                } catch (NumberFormatException e) {
                    // Handle the case where sets or reps are not valid numbers
                }
            } else {
                // Prompt the user that the fields cannot be empty
            }
        });

        return view;
    }
}