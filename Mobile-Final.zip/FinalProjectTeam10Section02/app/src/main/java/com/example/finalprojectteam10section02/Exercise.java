package com.example.finalprojectteam10section02;

import java.util.List;

public class Exercise {
    private long id;
    private long workoutId;
    private String name;
    private List<WorkoutSet> workoutSets;

    // Constructor, getters, and setters

    public Exercise() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getWorkoutId() {
        return workoutId;
    }

    public void setWorkoutId(long workoutId) {
        this.workoutId = workoutId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public List<WorkoutSet> getWorkoutSets() {
        return workoutSets;
    }
    public void setWorkoutSets(List<WorkoutSet> workoutSets) {
        this.workoutSets = workoutSets;
    }
}

