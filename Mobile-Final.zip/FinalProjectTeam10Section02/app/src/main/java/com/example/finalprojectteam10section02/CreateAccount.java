//Camila Terra Ramalho

package com.example.finalprojectteam10section02;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateAccount extends AppCompatActivity  implements AdapterView.OnItemSelectedListener {

    //declaring variables
    private EditText textViewName, textViewEmail, editTextTextConfirmPassword, editTextTextPassword;
    private DatePicker datePicker;
    private Spinner spinner;
    private String name, email, password, confirmPassword, error, gender;
    private String day, month, year;
    private String dob;
    private TextView textViewErrorMessage;
    private int n=0;
    DBHandler dbHandler;


    private Button buttonCreateAccount, buttonCreateCancel;

    private String[] genderDropDown = {"Male", "Female", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        //initializing all variables
        textViewName = findViewById(R.id.textViewName);
        textViewEmail = findViewById(R.id.textViewEmail);
        editTextTextConfirmPassword = findViewById(R.id.editTextTextConfirmPassword);
        editTextTextPassword = findViewById(R.id.editTextTextPassword);
        datePicker = findViewById(R.id.datePicker);
        spinner = findViewById(R.id.spinnerGender);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        buttonCreateCancel = findViewById(R.id.buttonCreateCancel);
        textViewErrorMessage = findViewById(R.id.textViewErrorMessage);

        dbHandler = new DBHandler(CreateAccount.this);


        //setting the spinner to show the options
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, genderDropDown);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener( this);

        buttonCreateCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoginPage = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intentLoginPage);
            }
        });

        //if the button "Create account" is pushed this method works
        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //cleaning the error message if there is any
                textViewErrorMessage.setText(" ");

                //saving in variables the date set by the user
                day = String.valueOf(datePicker.getDayOfMonth());
                month = String.valueOf(datePicker.getMonth());
                year = String.valueOf(datePicker.getYear());

                //cleaning variable's trash
                name="";
                email="";
                password="";
                confirmPassword="";
                error ="";
                dob="";
                Log.i("name 1", String.valueOf(name));

                Boolean bolName = false;
                Boolean bolEmail = false;
                Boolean bolPassword = false;
                Boolean bolConfirmPassword=false;


                // saving the inputs in variables to make validations
                name = textViewName.getText().toString();
                email = textViewEmail.getText().toString();
                password = editTextTextPassword.getText().toString();
                confirmPassword = editTextTextConfirmPassword.getText().toString();
                dob = day+"/"+month+"/"+year;
                Log.i("name 2", String.valueOf(name));

                //tests of the user filled all the needed data
                if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    if (name.isEmpty()) {
                        error += "\n Add a name;";
                    }

                    if (email.isEmpty()) {
                        error += "\n Add a email;";
                    }

                    if (password.isEmpty()) {
                        error += "\n Add a password;";
                    }

                    if (confirmPassword.isEmpty()) {
                        error += "\n Add the password confirmation;";
                    }
                } else if ( !verifyName() || !verifyEmail()) {
                    error = "Add the correct data to:";

                    if (!verifyName()){
                        error += "\n - Name";
                    }
                    if (!verifyEmail()){
                        error += "\n - Email";
                    }

                }

                if (!password.equals(confirmPassword))
                {
                    error += "\n - Password and confirmation of password does not match;";
                }
                if (!error.isEmpty())
                {
                    textViewErrorMessage.setText(error);
                    Toast.makeText(getApplicationContext(), "Insert the correct data", Toast.LENGTH_SHORT).show();
                } else
                {

                    dbHandler.addNewUser(name, dob, email, gender, password);
                    Intent intentHomePage = new Intent(getApplicationContext(), Home.class);
                    startActivity(intentHomePage);
                    Toast.makeText(getApplicationContext(), "Data saved", Toast.LENGTH_SHORT).show();

                }

            }
        });



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (position==0){
            gender= "Male";
        }
        else if (position==1){
            gender = "Female";
        } else {
            gender= "Other";
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        gender= "Male";
    }

    private boolean verifyName(){
        Pattern patternName = Pattern.compile("[A-Za-z]{2,40}");
        String testName = name;
        Matcher matcher = patternName.matcher(testName);
        if(matcher.matches()){
            return true;
        }
        else
            return false;
    }


    private boolean verifyEmail(){
        Pattern patternNEmail = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
        String testEmail = email;
        Matcher matcher = patternNEmail.matcher(testEmail);
        if(matcher.matches()){
            return true;
        }
        else
            return false;
    }

}