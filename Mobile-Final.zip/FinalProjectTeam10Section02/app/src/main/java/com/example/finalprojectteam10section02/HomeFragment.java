package com.example.finalprojectteam10section02;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ListView listViewWorkouts;
    private DBHandler dbHandler;
    private List<Workout> workoutList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        listViewWorkouts = view.findViewById(R.id.listViewWorkouts);
        dbHandler = new DBHandler(getActivity());
        workoutList = new ArrayList<>();

        // Retrieve workouts from the database
        workoutList.addAll(dbHandler.getAllWorkouts());

        // Set up the adapter
        WorkoutAdapter workoutAdapter = new WorkoutAdapter(getActivity(), workoutList);
        listViewWorkouts.setAdapter(workoutAdapter);

        listViewWorkouts.setOnItemClickListener((parent, itemView, position, id) -> {
            Workout selectedWorkout = workoutList.get(position);
            displayWorkoutDetails(selectedWorkout.getId());
        });
        return view;
    }
    private void displayWorkoutDetails(long workoutId) {
        ExerciseDetailsFragment exerciseDetailsFragment = ExerciseDetailsFragment.newInstance(workoutId);
        replaceFragment(exerciseDetailsFragment);
    }
    // Inner class for the adapter
    public class WorkoutAdapter extends ArrayAdapter<Workout> {
        public WorkoutAdapter(Context context, List<Workout> workouts) {
            super(context, 0, workouts);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_workout, parent, false);
            }

            TextView textViewWorkoutName = convertView.findViewById(R.id.textViewWorkoutName);
            TextView textViewWorkoutDate = convertView.findViewById(R.id.textViewWorkoutDate);

            Workout workout = getItem(position);

            if (workout != null) {
                textViewWorkoutName.setText(workout.getName());
                textViewWorkoutDate.setText(workout.getDate());
            }

            return convertView;
        }
    }
    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commitAllowingStateLoss();
    }
}
