// Camila Terra Ramalho

package com.example.finalprojectteam10section02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashScreenActivity extends AppCompatActivity {

    Animation logoAnimOut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        ImageView imageView2 = findViewById(R.id.imageView2);
        logoAnimOut = AnimationUtils.loadAnimation(this, R.anim.zoomout);

        imageView2.setAnimation(logoAnimOut);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                //setting a splash screen for the time of 4000 delayMillis
                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 4000);

    }
}