package com.example.finalprojectteam10section02;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class ExerciseDetailsFragment extends Fragment {

    private long workoutId;
    private TextView textViewWorkoutName;
    private ListView listViewExercises;
    private DBHandler dbHandler;
    private List<Exercise> exerciseList;

    public ExerciseDetailsFragment() {
        // Required empty public constructor
    }

    public static ExerciseDetailsFragment newInstance(long workoutId) {
        ExerciseDetailsFragment fragment = new ExerciseDetailsFragment();
        Bundle args = new Bundle();
        args.putLong("workout_id", workoutId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exercise_details, container, false);

        textViewWorkoutName = view.findViewById(R.id.textViewWorkoutName);
        listViewExercises = view.findViewById(R.id.listViewExercises);
        dbHandler = new DBHandler(getActivity());

        // Get the workout ID from the fragment arguments
        if (getArguments() != null) {
            workoutId = getArguments().getLong("workout_id");
        }

        // Retrieve the workout details and set the workout name
        Workout workout = dbHandler.getWorkoutById(workoutId);
        if (workout != null) {
            textViewWorkoutName.setText(workout.getName());
        }

        // Retrieve the exercises for the workout and set up the adapter
        exerciseList = dbHandler.getExercisesForWorkout(workoutId);
        ExerciseAdapter adapter = new ExerciseAdapter(getActivity(), exerciseList);
        listViewExercises.setAdapter(adapter);

        Button buttonAddExercise = view.findViewById(R.id.buttonAddExercise);
        buttonAddExercise.setOnClickListener(v -> openAddExerciseFragment());

        return view;
    }
    private void openAddExerciseFragment() {
        AddExercise addExerciseFragment = AddExercise.newInstance(workoutId); // Ensure this method exists and is properly set up to handle the workout ID
        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, addExerciseFragment);
        fragmentTransaction.addToBackStack(null); // If you want to add the transaction to backstack
        fragmentTransaction.commit();
    }
    private class ExerciseAdapter extends ArrayAdapter<Exercise> {
        ExerciseAdapter(Context context, List<Exercise> exercises) {
            super(context, 0, exercises);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_exercise, parent, false);
            }

            TextView textViewExerciseName = convertView.findViewById(R.id.textViewExerciseName);
            TextView textViewSets = convertView.findViewById(R.id.textViewSets);
            TextView textViewReps = convertView.findViewById(R.id.textViewReps);

            Exercise exercise = getItem(position);
            if (exercise != null) {
                textViewExerciseName.setText(exercise.getName());
                List<WorkoutSet> setsList = exercise.getWorkoutSets();
                if (setsList != null && !setsList.isEmpty()) {
                    // Assuming you just want to show the first set's details
                    WorkoutSet firstSet = setsList.get(0);
                    textViewSets.setText(String.valueOf(firstSet.getSets()));
                    textViewReps.setText(String.valueOf(firstSet.getReps()));
                }
            }

            return convertView;
        }
    }
}
